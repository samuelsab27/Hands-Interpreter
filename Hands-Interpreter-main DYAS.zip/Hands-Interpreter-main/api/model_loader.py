# api/model_loader.py

import pickle
import numpy as np
import os


model = None
scaler = None


def load_resources():
    """Carga el modelo y el scaler SOLO si no estamos en tests."""
    global model, scaler

    # Si los tests están corriendo NO cargar TensorFlow
    if os.environ.get("PYTEST_RUNNING") == "1":
        model = None
        scaler = None
        return

    # Cargar modelo real
    from keras.models import load_model

    MODEL_PATH = "hand_model.keras"
    SCALER_PATH = "scaler.pkl"

    model = load_model(MODEL_PATH)

    with open(SCALER_PATH, "rb") as f:
        scaler = pickle.load(f)


# --- IMPORTANTE: no llamamos load_resources() aquí ---
# Eso evita que el modelo cargue al importar el archivo.


def predict_keypoints(keypoints: list):
    """
    En tests, devuelve output fijo.
    En producción, usa el modelo real.
    """
    if model is None:
        return {"class": 0, "confidence": 1.0}

    arr = np.array(keypoints).reshape(1, -1)
    arr_scaled = scaler.transform(arr)
    pred = model.predict(arr_scaled)
    class_id = int(np.argmax(pred))
    confidence = float(np.max(pred))
    return {"class": class_id, "confidence": confidence}

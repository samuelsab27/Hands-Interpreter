# api/main.py

import os

# Detectar si estamos en pytest
IS_TEST = os.environ.get("PYTEST_RUNNING") == "1"

from fastapi import FastAPI
from pydantic import BaseModel
from typing import List
from pydantic import BaseModel


if not IS_TEST:
    # Importar el módulo completo, NO la función
    from api import model_loader
else:
    # Simulación para pruebas
    class FakeModel:
        @staticmethod
        def predict_keypoints(keypoints):
            return {"class": 0, "confidence": 1.0}

    model_loader = FakeModel()


app = FastAPI(
    title="Hands Interpreter API",
    description="API para predecir gestos con el modelo Keras",
    version="1.0"
)

class KeypointsRequest(BaseModel):
    keypoints: List[float] 


@app.get("/")
def home():
    return {"status": "ok"}



@app.post("/predict")
def predict(req: KeypointsRequest):
    # Llamamos SIEMPRE al módulo, no a la función
    return {"result": model_loader.predict_keypoints(req.keypoints)}

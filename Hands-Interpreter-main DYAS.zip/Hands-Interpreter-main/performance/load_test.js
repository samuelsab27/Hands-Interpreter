// performance/load_test_simple.js
import http from 'k6/http';
import { check, sleep } from 'k6';

export const options = {
  stages: [
    { duration: '10s', target: 5 },    // 5 usuarios en 10s
    { duration: '20s', target: 10 },   // 10 usuarios en 20s  
    { duration: '10s', target: 0 },    // bajar a 0
  ],
};

export default function () {
  // Usa el endpoint que SÍ funciona (health o predict)
  const res = http.get('http://localhost:8000/health');
  
  check(res, {
    'status is 200': (r) => r.status === 200,
    'response time < 2s': (r) => r.timings.duration < 2000,
  });
  
  sleep(1);
}
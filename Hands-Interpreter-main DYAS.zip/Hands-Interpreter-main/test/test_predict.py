from fastapi.testclient import TestClient
from api.main import app

client = TestClient(app)

def test_predict_endpoint():
    payload = {
        "keypoints": [0.1] * 42   # vector de 42 valores falsos
    }

    response = client.post("/predict", json=payload)

    # 1. El endpoint responde
    assert response.status_code == 200

    # 2. El contenido tiene la clave result
    data = response.json()
    assert "result" in data

    # 3. Como estamos en pytest debe usar el mock:
    #    {"class": 0, "confidence": 1.0}
    assert data["result"]["class"] == 0
    assert data["result"]["confidence"] == 1.0

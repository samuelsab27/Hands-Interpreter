from fastapi.testclient import TestClient
from api.main import app

client = TestClient(app)

def test_predict_invalid_keypoints():
    # Enviamos un cuerpo inválido (cadena en vez de números)
    data = {"keypoints": ["a", "b", "c"]}

    response = client.post("/predict", json=data)

    # Debe retornar 422 porque pydantic valida la entrada
    assert response.status_code == 422

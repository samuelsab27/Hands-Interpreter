from src.main.mainGestor import Main

if __name__=="__main__":
    app=Main()
    app.run()